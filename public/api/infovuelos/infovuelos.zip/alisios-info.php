    <?php
    if (count($pilots) != 0) 
    {
        foreach($pilots as $pilot){
                        
            if($pilot[1] == $_GET['cs']) //Bucamos infrmacion del vuelo definido en $_GET cs de la URL
            {
				
            }
        } 
    }
  ?>